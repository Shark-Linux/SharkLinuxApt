#!/usr/bin/env python

# This file is part of Window-Switch.
# Copyright (c) 2009-2013 Antoine Martin <antoine@nagafix.co.uk>
# Window-Switch is released under the terms of the GNU GPL v3

# Store common options in this file so we can reference them from both client and server classes
# without importing them (don't want to import client from server for example - might import gtk!)

CLIPBOARD = "clipboard"
FULLSCREEN = "fullscreen"
BANDWIDTH = "bandwidth"
JPEG_QUALITY_OPTION = "jpeg_quality"
ENCODING = "encoding"
COMPRESSION = "compression"
READ_ONLY = "read_only"
FRAMERATE = "framerate"
GST_VIDEOSCALE_METHOD = "gst_videoscale_method"
GST_VIDEO_CODEC = "gst_video_codec"
KEYBOARD_SYNC = "keyboard_sync"
KEYMAP = "keymap"
MMAP = "mmap"

TIMEZONE = "timezone"
LOCALE = "locale"

SCREEN_SIZE = "screen_size"
