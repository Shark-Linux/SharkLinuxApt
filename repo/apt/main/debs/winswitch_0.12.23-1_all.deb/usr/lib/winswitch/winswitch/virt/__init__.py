from winswitch import __version__, __author__, __email__
