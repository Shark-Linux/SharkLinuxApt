#!/usr/bin/env python

# This file is part of Window-Switch.
# Copyright (c) 2016 Antoine Martin <antoine@nagafix.co.uk>
# Window-Switch is released under the terms of the GNU GPL v3

import sys

def main():
	execfile(sys.argv[1])

if __name__ == "__main__":
	sys.exit(main())
