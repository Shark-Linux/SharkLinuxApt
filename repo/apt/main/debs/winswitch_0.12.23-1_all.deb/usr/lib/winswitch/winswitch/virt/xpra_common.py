#!/usr/bin/env python

# This file is part of Window-Switch.
# Copyright (c) 2009-2013 Antoine Martin <antoine@nagafix.co.uk>
# Window-Switch is released under the terms of the GNU GPL v3

from winswitch.globals import USER_ID, USERNAME
from winswitch.util.simple_logger import Logger

logger = Logger("xpra_common", log_colour=Logger.CYAN)


def xpra_cmd(username, xpra_command, xpra_args_list):
	if USER_ID==0 and username!=USERNAME:
		#FIXME: this is insecure and buggy...
		sub_cmd = xpra_command
		for arg in xpra_args_list:
			sub_cmd += " "+arg
		cmd_args = ["su", "-", "%s" % username, "-c", "%s" % sub_cmd]
	else:
		xpra_args = ""
		for arg in xpra_args_list:
			xpra_args += ", '"+arg+"'"
		cmd_args = xpra_args_list
		cmd_args.insert(0, xpra_command)
	return	cmd_args
