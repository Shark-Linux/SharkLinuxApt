#!/usr/bin/env python

# This file is part of Window-Switch.
# Copyright (c) 2009-2013 Antoine Martin <antoine@nagafix.co.uk>
# Window-Switch is released under the terms of the GNU GPL v3

import sys

def main():
	if sys.platform.startswith("win"):
		from winswitch.client.applet import logger, WinSwitchApplet
		logger.slog("main")
		exit_code = 0
		winswitch = None
		try:
			winswitch = WinSwitchApplet()
		except Exception, e:
			logger.exc(e)
			if winswitch:	#if we managed to load that class, display_error should have loaded too
				from winswitch.util.error_handling import display_error
				from winswitch.consts import APPLICATION_NAME
				display_error("%s failed to start" % APPLICATION_NAME, str(e))
			exit_code = 1
	
		if exit_code==0 and not winswitch.contact_existing_client():
			try:
				winswitch.run()
				logger.slog("run() ended")
			except Exception, e:
				logger.serr("caught exception, closing applet", e)
				exit_code = 1
				try:
					winswitch.cleanup()
				except Exception, e:
					logger.serror("exception during cleanup()", e)
		from winswitch.util.process_util import dump_threads
		dump_threads()
		logger.slog("main()=%s" % exit_code)
		from winswitch.util.simple_logger import rotate_log_file
		rotate_log_file()
		return exit_code
	else:
		from winswitch.util.paths import CLIENT_DIR, APPLET_LOG
		from winswitch.util.simple_logger import set_log_filename, set_log_dir
		set_log_dir(CLIENT_DIR)
		set_log_filename(APPLET_LOG)
		from winswitch.client.client_wrapper import parse_args
		if not parse_args():
			return
		from winswitch.client.applet import main
		return main()

if __name__ == "__main__":
	sys.exit(main())
