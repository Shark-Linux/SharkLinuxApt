__version_number__ = [0,12,23]
__version__ = ".".join(str(x) for x in __version_number__)
__author__ = "Antoine Martin"
__email__ = "Antoine at nagafix dot co dot uk"
