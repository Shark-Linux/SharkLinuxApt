__version__ = '4.0.4'
__appname__ = 'dupeGuru'

